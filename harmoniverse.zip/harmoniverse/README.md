# Harmoniverse

An educational website exploring **harmonics** — the shared pattern of vibration behind music and astronomy.

## Structure

```
index.html                  Home page: Harmoniverse + 3 topic cards + team link
harmonics-universe.html     "Harmonics in the Universe" (placeholder)
music.html                  "Harmonics and Music" hub with 3 sub-topic cards
  instrument-harmonics.html   (placeholder)
  clarinet-simulator.html     (placeholder)
  spectrogram.html            (placeholder)
astronomy.html              Interactive asteroseismology console (fully built)
team.html                   "Meet the Harmoniverse Team" (placeholder)
assets/css/style.css        Shared site styles (header, cards, buttons, footer)
```

## Publishing on GitHub Pages

1. Push this folder to a GitHub repository (e.g. `harmoniverse`).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, pick your default branch and `/ (root)`, then save.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.

No build step is required — everything is plain HTML/CSS/JS.

## Adding the topic icons later

Each of the three home page cards, and each of the three Music cards, currently uses a
simple inline SVG placeholder icon (`<span class="card-icon">…</span>`). To swap in a
final icon image:

1. Add your image file under `assets/icons/`.
2. Replace the inline `<svg>…</svg>` inside the matching `.card-icon` span with
   `<img src="assets/icons/your-icon.svg" alt="">` (keep `alt=""` since the card's
   heading already names the topic — the icon is decorative).

## Accessibility notes

- Every page has a "Skip to main content" link for keyboard users.
- Color is never the only way information is conveyed — every colored control or
  data series also has a text label.
- The accent colors (sky blue `#56b4e9`, orange `#e69f00`, bluish green `#009e73`,
  reddish purple `#cc79a7`) are drawn from the Okabe–Ito colorblind-safe palette.
- All interactive elements (links, buttons, sliders, the mode-selector chips) have
  a visible yellow focus ring and are reachable by keyboard alone.
- Animations (the header waveform, the live pulse dot) are paused for visitors who
  have `prefers-reduced-motion` set in their operating system.
- Canvas-based charts on the Astronomy page use `role="img"` with a descriptive
  `aria-label`, and every chart is paired with a plain-language caption below it.
